
import { defuFn } from 'D:/devapp/belajarnuxt/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default defuFn(inlineConfig)
